<?php
// Tüm Docker/dosya işlemleri. Argümanlar diziden gider (shell enjeksiyonu yok).

function dk(array $args, int $timeout = 60): array {
    $cmd = 'timeout ' . (int)$timeout . ' docker ' . implode(' ', array_map('escapeshellarg', $args)) . ' 2>&1';
    exec($cmd, $out, $code);
    return [$code, implode("\n", $out)];
}
function svc_container(int $sid): string { return "lh_$sid"; }

function docker_ensure_net(): void {
    [$c] = dk(['network', 'inspect', 'lemonhost']);
    if ($c !== 0) dk(['network', 'create', 'lemonhost']);
}

function docker_create(array $svc): array {
    docker_ensure_net();
    $n = svc_container((int)$svc['id']);
    $args = [
        'run', '-d', '--name', $n, '--hostname', $n, '--network', 'lemonhost',
        '--memory', $svc['ram_mb'] . 'm', '--memory-swap', $svc['ram_mb'] . 'm',
        '--cpus', (string)$svc['cpu'], '--pids-limit', '512',
        '--security-opt', 'no-new-privileges:true',
        '--cap-drop', 'ALL',
        '--cap-add', 'CHOWN', '--cap-add', 'SETUID', '--cap-add', 'SETGID',
        '--cap-add', 'DAC_OVERRIDE', '--cap-add', 'FOWNER',
        '--restart', 'unless-stopped',
    ];
    array_push($args, $svc['image'], 'sh', '-c', 'mkdir -p ' . cfg('work_dir') . ' && exec sleep infinity');
    return dk($args);
}

function docker_start(string $n): array { return dk(['start', $n]); }
function docker_stop(string $n): array  { return dk(['stop', $n]); }
function docker_rm(string $n): array    { return dk(['rm', '-f', $n]); }

/* ---------- Terminal (cwd takibi ile) ---------- */

function term_run(string $n, string $cwd, string $cmd): array {
    $script = 'cd "$1" 2>/dev/null || cd ' . cfg('work_dir') . '; eval "$2"; printf "\n__LH_PWD__%s" "$(pwd)"';
    [, $o] = dk(['exec', $n, 'sh', '-c', $script, 'sh', $cwd, $cmd]);
    $pos = strrpos($o, '__LH_PWD__');
    if ($pos === false) return [substr($o, 0, 20000), $cwd];
    $out = rtrim(substr($o, 0, $pos), "\n");
    $new = trim(substr($o, $pos + 10));
    return [substr($out, 0, 20000), $new ?: $cwd];
}

/* ---------- Dosya yöneticisi ---------- */

/** Panelden gelen göreli yolu konteyner içi mutlak yola çevirir (.. engelli, work_dir altında). */
function fs_path(string $rel): string {
    $rel = '/' . trim(str_replace('\\', '/', $rel), '/');
    if (preg_match('#(^|/)\.\.(/|$)#', $rel)) throw new RuntimeException('Geçersiz yol');
    $root = rtrim(cfg('work_dir'), '/');
    return $rel === '/' ? $root : $root . $rel;
}

function fs_list(string $n, string $full): array {
    [$c, $o] = dk(['exec', $n, 'sh', '-c',
        '[ -d "$1" ] || exit 3; find "$1" -mindepth 1 -maxdepth 1 -printf "%y|%s|%T@|%f\n" | sort -t"|" -k4',
        'sh', $full]);
    if ($c === 3) throw new RuntimeException('Klasör bulunamadı');
    $items = [];
    foreach (array_filter(explode("\n", $o)) as $line) {
        [$type, $size, $mtime, $name] = array_pad(explode('|', $line, 4), 4, '');
        $items[] = ['type' => $type, 'size' => (int)$size, 'mtime' => (int)$mtime, 'name' => $name];
    }
    usort($items, fn($a, $b) => ($a['type'] === 'd' ? 0 : 1) <=> ($b['type'] === 'd' ? 0 : 1));
    return $items;
}

function fs_read(string $n, string $full): string {
    [, $o] = dk(['exec', $n, 'sh', '-c', 'head -c 300000 -- "$1"', 'sh', $full]);
    return $o;
}

function fs_mkdir(string $n, string $full): void {
    dk(['exec', $n, 'sh', '-c', 'mkdir -p -- "$1"', 'sh', $full]);
}

function fs_rm(string $n, string $full): void {
    if (rtrim($full, '/') === rtrim(cfg('work_dir'), '/')) throw new RuntimeException('Kök klasör silinemez');
    dk(['exec', $n, 'sh', '-c', 'rm -rf -- "$1"', 'sh', $full]);
}

function fs_write(string $n, string $full, string $content): void {
    fs_mkdir($n, dirname($full));
    $tmp = tempnam(sys_get_temp_dir(), 'lh');
    file_put_contents($tmp, $content);
    [$c, $o] = dk(['cp', $tmp, "$n:$full"]);
    unlink($tmp);
    if ($c !== 0) throw new RuntimeException('Yazılamadı: ' . $o);
}

/** Konteynerden host'a kopyalar, geçici dosya yolunu döner (çağıran siler). */
function fs_fetch(string $n, string $full): string {
    $tmp = tempnam(sys_get_temp_dir(), 'lh');
    [$c, $o] = dk(['cp', "$n:$full", $tmp]);
    if ($c !== 0) { unlink($tmp); throw new RuntimeException('İndirilemedi: ' . $o); }
    return $tmp;
}

function fs_upload_from(string $n, string $dirFull, string $name, string $tmpSrc): void {
    fs_mkdir($n, $dirFull);
    [$c, $o] = dk(['cp', $tmpSrc, "$n:" . rtrim($dirFull, '/') . '/' . $name]);
    if ($c !== 0) throw new RuntimeException('Yüklenemedi: ' . $o);
}

/* ---------- Imaj ---------- */

function image_pull(string $ref): void {
    [$c, $o] = dk(['pull', $ref], 900);
    if ($c !== 0) throw new RuntimeException('Pull başarısız: ' . $o);
}

/* ---------- Cloudflare ve cloudflared: panelde yok (dışarı açmayı sen yapıyorsun) ---------- */

/* ---------- Panel tarafı disk kotası (Docker storage-opt kullanılmıyor) ---------- */

/** Konteyner içi /data boyutu (MB). */
function disk_used_mb(string $n): int {
    [$c, $o] = dk(['exec', $n, 'sh', '-c', 'du -sm /data 2>/dev/null | cut -f1'], 120);
    return $c === 0 ? (int)trim($o) : 0;
}

/** Yazma öncesi kontrol. disk_mb = 0 ise sınırsız. Kullanım + ek boyut limiti aşarsa hata. */
function disk_check(array $svc, int $addMb = 0): void {
    $limit = (int)$svc['disk_mb'];
    if ($limit <= 0) return;
    $used = disk_used_mb(svc_container((int)$svc['id']));
    db()->prepare("UPDATE services SET disk_used_mb=? WHERE id=?")->execute([$used, $svc['id']]);
    if ($used + $addMb > $limit) {
        throw new RuntimeException("Disk kotası dolu ({$used}/{$limit} MB). Önce dosya sil.");
    }
}
