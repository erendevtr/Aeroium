#!/usr/bin/env bash
# LemonHost kurulum (Debian/Ubuntu). Panel dışarıya senin cloudflared'ınla açılır.
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Root olarak çalıştır: sudo bash install.sh"; exit 1; }

DIR=/opt/lemonhost
SRC="$(cd "$(dirname "$0")" && pwd)"

echo "[1/5] Paketler..."
apt-get update -y
apt-get install -y php-cli php-sqlite3 php-curl openssl curl
if command -v docker >/dev/null 2>&1; then
  echo "  Docker zaten kurulu: $(docker --version)"
else
  apt-get install -y docker.io
fi
systemctl enable --now docker
docker info >/dev/null 2>&1 || { echo "Docker daemon çalışmıyor: systemctl status docker"; exit 1; }

echo "[2/5] Admin ayarları..."
read -rsp "Admin şifre: " ADMIN_PASS; echo
read -rp "Admin e-posta: " ADMIN_EMAIL
mkdir -p "$DIR/data"
cp -r "$SRC/public" "$SRC/lib" "$SRC/cron.php" "$SRC/config.php" "$DIR/"

echo "[3/5] Veritabanı ve admin..."
ADMIN_EMAIL="$ADMIN_EMAIL" ADMIN_PASS="$ADMIN_PASS" php -r '
require "/opt/lemonhost/lib/core.php";
db()->prepare("INSERT OR IGNORE INTO users(email,pass,is_admin,credits) VALUES(?,?,1,100)")
  ->execute([getenv("ADMIN_EMAIL"), password_hash(getenv("ADMIN_PASS"), PASSWORD_DEFAULT)]);
echo "  admin hazır\n";
'

echo "[4/5] systemd servisi..."
cat > /etc/systemd/system/lemonhost.service <<UNIT
[Unit]
Description=LemonHost Panel
After=network.target docker.service

[Service]
ExecStart=/usr/bin/php -S 127.0.0.1:8080 -t $DIR/public
Restart=always

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now lemonhost

echo "[5/5] Cron (10 dakikada bir)..."
(crontab -l 2>/dev/null | grep -v lemonhost/cron.php || true; \
 echo "*/10 * * * * /usr/bin/php $DIR/cron.php >> /var/log/lemonhost.log 2>&1") | crontab -

echo
echo "Hazır. Panel: http://127.0.0.1:8080 (cloudflared'ını buraya yönlendir)"
