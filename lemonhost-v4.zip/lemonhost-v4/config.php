<?php
return [
    'app'               => 'LemonHost',
    'db'                => __DIR__ . '/data/lemonhost.sqlite',
    'period_days'       => 30,    // her yenileme süresi
    'delete_after_days' => 7,     // askıda kalınca silinme süresi
    'hard_factor'       => 1.5,   // limit x bu oranı aşılırsa cron konteyneri durdurur
    'work_dir'          => '/data',
];
