<?php
require __DIR__ . '/../lib/core.php';
session_start();

/* ---- Dosya indirme (HTML çıkmadan önce) ---- */
if (($_GET['p'] ?? '') === 'dl') {
    $me = me();
    $sv = $me ? svc_owned((int)$_GET['id'], $me['id']) : null;
    if (!$sv) { http_response_code(403); exit('Yetkisiz'); }
    $tmp = fs_fetch(svc_container((int)$sv['id']), fs_path($_GET['path'] ?? ''));
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($_GET['path']) . '"');
    header('Content-Length: ' . filesize($tmp));
    readfile($tmp); unlink($tmp); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) { http_response_code(419); exit('CSRF hatası'); }
    $a = $_POST['a'] ?? '';

    if ($a === 'login') {
        $s = db()->prepare("SELECT * FROM users WHERE email=?");
        $s->execute([trim($_POST['email'] ?? '')]);
        $u = $s->fetch();
        if ($u && password_verify($_POST['pass'] ?? '', $u['pass'])) {
            session_regenerate_id(true);
            $_SESSION['uid'] = $u['id'];
            go('?p=dash');
        }
        flash('Hatalı giriş'); go('?p=login');
    }
    if ($a === 'logout') { session_destroy(); go('?p=login'); }

    $me = me();
    if (!$me) go('?p=login');
    $back = '?p=dash';
    $sid = (int)($_POST['id'] ?? 0);

    try {
        switch ($a) {
            case 'create':
                $pl = db()->prepare("SELECT * FROM plans WHERE id=?");
                $pl->execute([(int)($_POST['plan'] ?? 0)]);
                $plan = $pl->fetch();
                if (!$plan) throw new RuntimeException('Paket bulunamadı');
                if ($me['credits'] < $plan['price']) throw new RuntimeException('Yetersiz kredi');
                $name = substr(trim($_POST['name'] ?? '') ?: 'server', 0, 40);
                db()->prepare("INSERT INTO services(user_id,plan_id,name,status,expires_at,suspended_at,created_at)
                    VALUES(?,?,?,'suspended',?,?,?)")
                    ->execute([$me['id'], $plan['id'], $name, time() - 1, time(), time()]);
                $sid = (int)db()->lastInsertId();
                $sv = svc_owned($sid, $me['id']);
                [$c, $o] = docker_create($sv);
                if ($c !== 0) {
                    db()->prepare("DELETE FROM services WHERE id=?")->execute([$sid]);
                    throw new RuntimeException('Docker: ' . $o);
                }
                if (!renew_service($sid)) {
                    docker_rm(svc_container($sid));
                    db()->prepare("DELETE FROM services WHERE id=?")->execute([$sid]);
                    throw new RuntimeException('Yetersiz kredi');
                }
                flash('Sunucu oluşturuldu');
                $back = "?p=svc&id=$sid";
                break;

            case 'renew':
                if (!svc_owned($sid, $me['id'])) throw new RuntimeException('Yetkisiz');
                if (!renew_service($sid)) throw new RuntimeException('Yenileme başarısız (kredi yetersiz)');
                flash('Yenilendi');
                $back = "?p=svc&id=$sid";
                break;

            case 'power':
                $s = svc_owned($sid, $me['id']);
                if (!$s || $s['status'] !== 'active') throw new RuntimeException('Sunucu aktif değil');
                ($_POST['op'] ?? '') === 'stop' ? docker_stop(svc_container($sid)) : docker_start(svc_container($sid));
                $back = "?p=svc&id=$sid";
                break;

            case 'cmd':
                $s = svc_owned($sid, $me['id']);
                if (!$s || $s['status'] !== 'active') throw new RuntimeException('Sunucu aktif değil');
                $cmd = substr($_POST['cmd'] ?? '', 0, 2000);
                $cwd = $_SESSION['cwd'][$sid] ?? cfg('work_dir');
                [$out, $newCwd] = term_run(svc_container($sid), $cwd, $cmd);
                $_SESSION['cwd'][$sid] = $newCwd;
                $_SESSION['term'][$sid] = ['cmd' => $cmd, 'cwd' => $cwd, 'out' => $out];
                $back = "?p=svc&id=$sid";
                break;

            case 'fs_mkdir':
            case 'fs_rm':
            case 'fs_save':
            case 'fs_upload':
                $s = svc_owned($sid, $me['id']);
                if (!$s || $s['status'] !== 'active') throw new RuntimeException('Sunucu aktif değil');
                $n = svc_container($sid);
                $dir = $_POST['dir'] ?? '/';
                $back = "?p=files&id=$sid&dir=" . urlencode($dir);
                if ($a === 'fs_mkdir') {
                    $name = basename(trim($_POST['name'] ?? ''));
                    if ($name === '' || $name === '.' || $name === '..') throw new RuntimeException('Geçersiz ad');
                    fs_mkdir($n, rtrim(fs_path($dir), '/') . '/' . $name);
                }
                if ($a === 'fs_rm') fs_rm($n, fs_path($_POST['path'] ?? ''));
                if ($a === 'fs_save') {
                    fs_write($n, fs_path($_POST['path'] ?? ''), str_replace("\r\n", "\n", $_POST['content'] ?? ''));
                    $back = "?p=edit&id=$sid&path=" . urlencode($_POST['path'] ?? '');
                    flash('Kaydedildi');
                    break;
                }
                if ($a === 'fs_upload') {
                    $f = $_FILES['file'] ?? null;
                    if (!$f || $f['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Yükleme hatası');
                    if ($f['size'] > 50 * 1024 * 1024) throw new RuntimeException('En fazla 50 MB');
                    $name = basename($f['name']);
                    fs_upload_from($n, fs_path($dir), $name, $f['tmp_name']);
                }
                break;

            case 'plan_del':
                if (!$me['is_admin']) throw new RuntimeException('Yetkisiz');
                $pid = (int)($_POST['plan_id'] ?? 0);
                $c = db()->prepare("SELECT COUNT(*) c FROM services WHERE plan_id=?");
                $c->execute([$pid]);
                if ($c->fetch()['c'] > 0) throw new RuntimeException('Bu pakete bağlı sunucu kayıtları var, silinemez');
                db()->prepare("DELETE FROM plans WHERE id=?")->execute([$pid]);
                flash('Paket silindi');
                $back = '?p=admin';
                break;

            case 'credit':
                if (!$me['is_admin']) throw new RuntimeException('Yetkisiz');
                db()->prepare("UPDATE users SET credits=credits+? WHERE id=?")
                    ->execute([(float)$_POST['amount'], (int)$_POST['uid']]);
                flash('Kredi eklendi');
                $back = '?p=admin';
                break;

            case 'image':
                if (!$me['is_admin']) throw new RuntimeException('Yetkisiz');
                $ref = trim($_POST['ref'] ?? '');
                $label = substr(trim($_POST['label'] ?? '') ?: $ref, 0, 60);
                if (!preg_match('#^[a-z0-9][a-z0-9._/:@-]{1,200}$#i', $ref)) throw new RuntimeException('Geçersiz imaj adı');
                image_pull($ref);
                db()->prepare("INSERT INTO images(label,ref) VALUES(?,?)")->execute([$label, $ref]);
                flash('İmaj eklendi');
                $back = '?p=admin';
                break;

            case 'plan':
                if (!$me['is_admin']) throw new RuntimeException('Yetkisiz');
                db()->prepare("INSERT INTO plans(name,price,cpu,ram_mb,disk_mb,image_id) VALUES(?,?,?,?,?,?)")
                    ->execute([
                        substr(trim($_POST['name']), 0, 40), (float)$_POST['price'], (float)$_POST['cpu'],
                        (int)$_POST['ram_mb'], (int)$_POST['disk_mb'], (int)$_POST['image_id'],
                    ]);
                flash('Paket eklendi');
                $back = '?p=admin';
                break;
        }
    } catch (Throwable $ex) {
        flash('Hata: ' . $ex->getMessage());
    }
    go($back);
}

$me = me();
$p = $_GET['p'] ?? 'dash';
if (!$me && $p !== 'login') go('?p=login');
if ($me && $p === 'login') go('?p=dash');
$f = flash();
$sid = (int)($_GET['id'] ?? 0);
$sv = $me && $sid ? svc_owned($sid, $me['id']) : null;
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e(cfg('app')) ?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php if ($me): ?>
<header class="top">
  <a class="brand" href="?p=dash">🍋 <?= e(cfg('app')) ?></a>
  <nav>
    <span class="credits"><?= number_format($me['credits'], 2) ?> kredi</span>
    <?php if ($me['is_admin']): ?><a href="?p=admin">Admin</a><?php endif; ?>
    <form method="post" class="inline">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <button name="a" value="logout" class="ghost">Çıkış</button>
    </form>
  </nav>
</header>
<?php endif; ?>

<main>
<?php if ($f): ?><div class="flash"><?= e($f) ?></div><?php endif; ?>

<?php if ($p === 'login'): ?>
  <section class="card narrow">
    <h1>Giriş</h1>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <label>E-posta <input name="email" type="email" required></label>
      <label>Şifre <input name="pass" type="password" required></label>
      <button name="a" value="login">Giriş yap</button>
    </form>
  </section>

<?php elseif ($p === 'dash'): ?>
  <h1>Sunucularım</h1>
  <div class="grid">
  <?php
    $s = db()->prepare(SVC_SQL . " WHERE s.user_id=? AND s.status!='deleted' ORDER BY s.id DESC");
    $s->execute([$me['id']]);
    foreach ($s->fetchAll() as $x): ?>
    <a class="card server" href="?p=svc&id=<?= $x['id'] ?>">
      <div class="row"><strong><?= e($x['name']) ?></strong>
        <span class="badge <?= e($x['status']) ?>"><?= e($x['status']) ?></span></div>
      <small><?= e($x['plan']) ?> · <?= e($x['image']) ?> · bitiş <?= date('d.m.Y', $x['expires_at']) ?></small>
    </a>
  <?php endforeach; ?>
  </div>

  <section class="card">
    <h2>Yeni sunucu</h2>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input name="name" placeholder="Sunucu adı" maxlength="40">
      <div class="grid">
      <?php foreach (db()->query("SELECT p.*, i.label img FROM plans p JOIN images i ON i.id=p.image_id")->fetchAll() as $pl): ?>
        <label class="card plan">
          <input type="radio" name="plan" value="<?= $pl['id'] ?>" <?= $pl['id'] == 1 ? 'checked' : '' ?>>
          <strong><?= e($pl['name']) ?></strong>
          <div><?= rtrim(rtrim(number_format($pl['price'], 2), '0'), '.') ?> kredi / <?= cfg('period_days') ?> gün</div>
          <small><?= $pl['cpu'] ?> vCPU · <?= $pl['ram_mb'] ?> MB RAM<?= $pl['disk_mb'] ? ' · ' . round($pl['disk_mb'] / 1024, 1) . ' GB disk' : '' ?></small>
          <small><?= e($pl['img']) ?></small>
        </label>
      <?php endforeach; ?>
      </div>
      <button name="a" value="create">Oluştur</button>
    </form>
  </section>

<?php elseif ($p === 'svc' && $sv):
    $logs = db()->prepare("SELECT msg, at FROM log WHERE service_id=? ORDER BY id DESC LIMIT 10");
    $logs->execute([$sid]);
    $term = $_SESSION['term'][$sid] ?? null;
    $cwd = $_SESSION['cwd'][$sid] ?? cfg('work_dir');
?>
  <h1><?= e($sv['name']) ?> <span class="badge <?= e($sv['status']) ?>"><?= e($sv['status']) ?></span></h1>
  <p>Bitiş: <?= date('d.m.Y H:i', $sv['expires_at']) ?>
    <?php if ($sv['status'] === 'suspended'): ?> · <strong>Askıda.</strong> Yenilemezsen <?= cfg('delete_after_days') ?> gün içinde silinir.<?php endif; ?></p>

  <div class="actions">
    <form method="post" class="inline">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="id" value="<?= $sid ?>">
      <button name="a" value="renew">Yenile (<?= rtrim(rtrim(number_format($sv['price'], 2), '0'), '.') ?> kredi)</button>
    </form>
    <?php if ($sv['status'] === 'active'): ?>
    <form method="post" class="inline">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="id" value="<?= $sid ?>">
      <input type="hidden" name="op" value="start">
      <button name="a" value="power" class="ghost">Başlat</button>
    </form>
    <form method="post" class="inline">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="id" value="<?= $sid ?>">
      <input type="hidden" name="op" value="stop">
      <button name="a" value="power" class="ghost">Durdur</button>
    </form>
    <a class="btn-link" href="?p=files&id=<?= $sid ?>">📁 Dosyalar</a>
    <?php endif; ?>
  </div>

  <section class="card terminal">
    <h2>Terminal</h2>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="id" value="<?= $sid ?>">
      <div class="row"><span class="prompt"><?= e($cwd) ?> $</span>
        <input name="cmd" placeholder="ls -la" autocomplete="off" required <?= $sv['status'] !== 'active' ? 'disabled' : '' ?>>
        <button name="a" value="cmd" <?= $sv['status'] !== 'active' ? 'disabled' : '' ?>>Çalıştır</button></div>
    </form>
    <?php if ($term): ?>
      <pre><span class="prompt"><?= e($term['cwd']) ?> $ <?= e($term['cmd']) ?></span>
<?= e($term['out']) ?></pre>
    <?php endif; ?>
  </section>

  <section class="card">
    <h2>Geçmiş</h2>
    <ul class="log"><?php foreach ($logs->fetchAll() as $l): ?>
      <li><small><?= date('d.m H:i', $l['at']) ?></small> <?= e($l['msg']) ?></li>
    <?php endforeach; ?></ul>
  </section>

<?php elseif ($p === 'files' && $sv):
    $dir = $_GET['dir'] ?? '/';
    $full = fs_path($dir);
    $rel = '/' . trim($dir, '/');
    $items = [];
    try { $items = fs_list(svc_container($sid), $full); } catch (Throwable $ex) { flash('Hata: ' . $ex->getMessage()); }
    $parts = array_values(array_filter(explode('/', trim($rel, '/'))));
?>
  <h1>Dosyalar</h1>
  <p class="crumb"><a href="?p=svc&id=<?= $sid ?>">← Sunucu</a> &nbsp;/ <a href="?p=files&id=<?= $sid ?>&dir=/">data</a>
    <?php $acc = ''; foreach ($parts as $pp): $acc .= '/' . $pp; ?>
      / <a href="?p=files&id=<?= $sid ?>&dir=<?= urlencode($acc) ?>"><?= e($pp) ?></a>
    <?php endforeach; ?></p>

  <section class="card">
    <table class="fm">
      <tr><th>Ad</th><th>Boyut</th><th>Değiştirilme</th><th></th></tr>
      <?php foreach ($items as $it):
        $child = rtrim($rel, '/') . '/' . $it['name']; ?>
      <tr>
        <td><?php if ($it['type'] === 'd'): ?>📁 <a href="?p=files&id=<?= $sid ?>&dir=<?= urlencode($child) ?>"><?= e($it['name']) ?></a>
            <?php else: ?>📄 <a href="?p=edit&id=<?= $sid ?>&path=<?= urlencode($child) ?>"><?= e($it['name']) ?></a><?php endif; ?></td>
        <td><small><?= $it['type'] === 'd' ? '—' : number_format($it['size'] / 1024, 1) . ' KB' ?></small></td>
        <td><small><?= date('d.m.Y H:i', $it['mtime']) ?></small></td>
        <td class="right">
          <?php if ($it['type'] !== 'd'): ?>
            <a class="btn-link" href="?p=dl&id=<?= $sid ?>&path=<?= urlencode($child) ?>">İndir</a>
          <?php endif; ?>
          <form method="post" class="inline" onsubmit="return confirm('Silinsin mi?')">
            <input type="hidden" name="csrf" value="<?= csrf() ?>">
            <input type="hidden" name="id" value="<?= $sid ?>">
            <input type="hidden" name="dir" value="<?= e($rel) ?>">
            <input type="hidden" name="path" value="<?= e($child) ?>">
            <button name="a" value="fs_rm" class="ghost danger">Sil</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
  </section>

  <div class="grid">
    <section class="card">
      <h2>Klasör oluştur</h2>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf() ?>">
        <input type="hidden" name="id" value="<?= $sid ?>">
        <input type="hidden" name="dir" value="<?= e($rel) ?>">
        <input name="name" placeholder="klasor-adi" required>
        <button name="a" value="fs_mkdir">Oluştur</button>
      </form>
    </section>
    <section class="card">
      <h2>Dosya yükle (max 50 MB)</h2>
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf" value="<?= csrf() ?>">
        <input type="hidden" name="id" value="<?= $sid ?>">
        <input type="hidden" name="dir" value="<?= e($rel) ?>">
        <input type="file" name="file" required>
        <button name="a" value="fs_upload">Yükle</button>
      </form>
    </section>
  </div>

<?php elseif ($p === 'edit' && $sv):
    $path = $_GET['path'] ?? '';
    $content = '';
    try { $content = fs_read(svc_container($sid), fs_path($path)); } catch (Throwable $ex) { flash('Hata: ' . $ex->getMessage()); }
    $dirOf = dirname('/' . ltrim($path, '/'));
?>
  <h1><?= e(basename($path)) ?></h1>
  <p class="crumb"><a href="?p=files&id=<?= $sid ?>&dir=<?= urlencode($dirOf) ?>">← Dosyalar</a></p>
  <section class="card">
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <input type="hidden" name="id" value="<?= $sid ?>">
      <input type="hidden" name="path" value="<?= e($path) ?>">
      <textarea name="content" rows="24" spellcheck="false"><?= e($content) ?></textarea>
      <button name="a" value="fs_save">Kaydet</button>
    </form>
  </section>

<?php elseif ($p === 'admin' && $me['is_admin']): ?>
  <h1>Admin</h1>
  <section class="card">
    <h2>Kullanıcılar</h2>
    <table>
      <tr><th>ID</th><th>E-posta</th><th>Kredi</th><th>Kredi ekle</th></tr>
      <?php foreach (db()->query("SELECT * FROM users")->fetchAll() as $u): ?>
      <tr>
        <td><?= $u['id'] ?></td><td><?= e($u['email']) ?></td><td><?= number_format($u['credits'], 2) ?></td>
        <td>
          <form method="post" class="inline">
            <input type="hidden" name="csrf" value="<?= csrf() ?>">
            <input type="hidden" name="uid" value="<?= $u['id'] ?>">
            <input name="amount" type="number" step="0.01" value="10" class="small">
            <button name="a" value="credit">Ekle</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
  </section>

  <div class="grid">
    <section class="card">
      <h2>İmaj ekle</h2>
      <p><small>Docker Hub'daki imaj adı. Eklerken pull edilir.</small></p>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf() ?>">
        <input name="label" placeholder="Görünen ad (örn: Ubuntu 24.04)">
        <input name="ref" placeholder="ubuntu:24.04" required>
        <button name="a" value="image">Ekle ve pull et</button>
      </form>
      <h2 style="margin-top:18px">Mevcut imajlar</h2>
      <ul class="log"><?php foreach (db()->query("SELECT * FROM images")->fetchAll() as $im): ?>
        <li><?= e($im['label']) ?> <small>(<?= e($im['ref']) ?>)</small></li>
      <?php endforeach; ?></ul>
    </section>

    <section class="card">
      <h2>Paket ekle</h2>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf() ?>">
        <input name="name" placeholder="Paket adı" required>
        <div class="row">
          <label>Fiyat <input name="price" type="number" step="0.01" value="0"></label>
          <label>vCPU <input name="cpu" type="number" step="0.1" value="1"></label>
        </div>
        <div class="row">
          <label>RAM (MB) <input name="ram_mb" type="number" value="1024"></label>
          <label>Disk (MB, 0=sınırsız) <input name="disk_mb" type="number" value="0"></label>
        </div>
        <label>İmaj
          <select name="image_id">
          <?php foreach (db()->query("SELECT * FROM images")->fetchAll() as $im): ?>
            <option value="<?= $im['id'] ?>"><?= e($im['label']) ?></option>
          <?php endforeach; ?>
          </select>
        </label>
        <button name="a" value="plan">Paketi ekle</button>
      </form>
      <h2 style="margin-top:18px">Mevcut paketler</h2>
      <table class="fm">
      <?php foreach (db()->query("SELECT p.*, i.label img,
            (SELECT COUNT(*) FROM services s WHERE s.plan_id=p.id) cnt
            FROM plans p JOIN images i ON i.id=p.image_id")->fetchAll() as $pl): ?>
        <tr>
          <td><?= e($pl['name']) ?> <br><small><?= e($pl['img']) ?> · <?= $pl['price'] ?> kredi</small></td>
          <td class="right">
          <?php if ($pl['cnt']): ?>
            <small>Kullanımda (<?= $pl['cnt'] ?> sunucu)</small>
          <?php else: ?>
            <form method="post" class="inline" onsubmit="return confirm('Paket silinsin mi?')">
              <input type="hidden" name="csrf" value="<?= csrf() ?>">
              <input type="hidden" name="plan_id" value="<?= $pl['id'] ?>">
              <button name="a" value="plan_del" class="ghost danger">Sil</button>
            </form>
          <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </table>
    </section>
  </div>

<?php else: echo '<p>Sayfa bulunamadı.</p>'; endif; ?>
</main>
</body>
</html>
