#!/usr/bin/env bash
# LemonHost kurulum (Debian/Ubuntu). Panel dışarıya senin cloudflared'ınla açılır.
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Root olarak çalıştır: sudo bash install.sh"; exit 1; }
DIR=/opt/lemonhost
SRC="$(cd "$(dirname "$0")" && pwd)"
IMG=/var/lib/docker-xfs.img

echo "[1/6] Paketler..."
apt-get update -y
apt-get install -y php-cli php-sqlite3 php-curl docker.io openssl util-linux xfsprogs
systemctl enable --now docker

echo "[2/6] Disk limiti altyapısı (XFS + prjquota)..."
docker_has_data() {
  [[ -n "$(docker ps -aq 2>/dev/null || true)" || -n "$(docker images -q 2>/dev/null || true)" ]]
}
prjquota_ready() {
  grep -q " /var/lib/docker xfs .*prjquota" /proc/mounts
}
setup_disk() {
  prjquota_ready && return 0
  if docker_has_data; then
    echo "  Docker'da mevcut konteyner/imaj var. /var/lib/docker otomatik taşınmıyor."
    echo "  Önce temizleyip (docker system prune -a) tekrar çalıştır, ya da disk limitini kapalı bırak."
    return 1
  fi
  local GB
  read -rp "  Disk havuzu boyutu GB [50]: " GB; GB=${GB:-50}
  systemctl stop docker docker.socket 2>/dev/null || true
  mkdir -p /var/lib/docker
  umount /var/lib/docker 2>/dev/null || true
  if [[ ! -f $IMG ]]; then truncate -s "${GB}G" "$IMG"; fi
  if ! blkid "$IMG" >/dev/null 2>&1; then mkfs.xfs -q "$IMG"; fi
  grep -q "docker-xfs.img" /etc/fstab || echo "$IMG /var/lib/docker xfs loop,prjquota 0 0" >> /etc/fstab
  mount /var/lib/docker
  mkdir -p /etc/docker
  if [[ ! -f /etc/docker/daemon.json ]]; then
    cat > /etc/docker/daemon.json <<JSON
{ "storage-driver": "overlay2" }
JSON
  fi
  systemctl start docker
  prjquota_ready
}
DISK_LIMIT=0
if setup_disk; then
  DISK_LIMIT=1
  echo "  Disk limiti AKTİF (/var/lib/docker XFS prjquota)"
else
  echo "  UYARI: Disk limiti kapalı. Paketlerdeki disk değeri uygulanmaz."
fi

echo "[3/6] Admin ayarları..."
read -rsp "Admin şifre: " ADMIN_PASS; echo
read -rp "Admin e-posta: " ADMIN_EMAIL
mkdir -p "$DIR/data"
cp -r "$SRC/public" "$SRC/lib" "$SRC/cron.php" "$SRC/config.php" "$DIR/"
cat > "$DIR/.env" <<ENV
LH_DISK_LIMIT=$DISK_LIMIT
ENV
chmod 600 "$DIR/.env"

echo "[4/6] Veritabanı ve admin..."
ADMIN_EMAIL="$ADMIN_EMAIL" ADMIN_PASS="$ADMIN_PASS" php -r '
require "/opt/lemonhost/lib/core.php";
db()->prepare("INSERT OR IGNORE INTO users(email,pass,is_admin,credits) VALUES(?,?,1,100)")
  ->execute([getenv("ADMIN_EMAIL"), password_hash(getenv("ADMIN_PASS"), PASSWORD_DEFAULT)]);
echo "  admin hazır\n";
'

echo "[5/6] systemd servisi..."
cat > /etc/systemd/system/lemonhost.service <<UNIT
[Unit]
Description=LemonHost Panel
After=network.target docker.service

[Service]
EnvironmentFile=$DIR/.env
ExecStart=/usr/bin/php -S 127.0.0.1:8080 -t $DIR/public
Restart=always

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now lemonhost

echo "[6/6] Cron (10 dk'da bir)..."
(crontab -l 2>/dev/null | grep -v lemonhost/cron.php || true; echo "*/10 * * * * /usr/bin/php $DIR/cron.php >> /var/log/lemonhost.log 2>&1") | crontab -

echo
echo "Hazır. Panel: http://127.0.0.1:8080 (cloudflared'ını buraya yönlendir)"
