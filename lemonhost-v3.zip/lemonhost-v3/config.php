<?php
return [
    'app'               => 'LemonHost',
    'db'                => __DIR__ . '/data/lemonhost.sqlite',
    'disk_limit'        => getenv('LH_DISK_LIMIT') === '1',
    'period_days'       => 30,  // her yenileme süresi
    'delete_after_days' => 7,   // askıda kalınca silinme süresi
    'work_dir'          => '/data', // konteyner içi çalışma/dosya kökü
];
