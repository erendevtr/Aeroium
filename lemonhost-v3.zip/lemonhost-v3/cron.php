<?php
// 10 dakikada bir: oto yenileme -> süresi dolanı askıya al -> uzun askıdakileri sil
require __DIR__ . '/lib/core.php';
$pdo = db();
$now = time();

$q = $pdo->query("SELECT s.id FROM services s JOIN users u ON u.id=s.user_id
    WHERE s.status='active' AND u.auto_renew=1 AND s.expires_at < " . ($now + 3600));
foreach ($q->fetchAll() as $r) renew_service((int)$r['id'], true);

foreach ($pdo->query("SELECT id FROM services WHERE status='active' AND expires_at < $now")->fetchAll() as $r) {
    $sid = (int)$r['id'];
    docker_stop(svc_container($sid));
    $pdo->prepare("UPDATE services SET status='suspended', suspended_at=? WHERE id=?")->execute([$now, $sid]);
    logmsg($sid, 'Süre doldu, askıya alındı');
}

$q = $pdo->prepare("SELECT id FROM services WHERE status='suspended' AND suspended_at < ?");
$q->execute([$now - cfg('delete_after_days') * 86400]);
foreach ($q->fetchAll() as $r) {
    $sid = (int)$r['id'];
    docker_rm(svc_container($sid));
    $pdo->prepare("UPDATE services SET status='deleted' WHERE id=?")->execute([$sid]);
    logmsg($sid, 'Silindi (askıda süre doldu)');
}
echo "ok " . date('c') . "\n";
