<?php
function cfg(string $k) {
    static $c = null;
    $c ??= require dirname(__DIR__) . '/config.php';
    return $c[$k] ?? null;
}

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $pdo = new PDO('sqlite:' . cfg('db'));
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys=ON');
    $pdo->exec("CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, pass TEXT NOT NULL,
        credits REAL NOT NULL DEFAULT 0, is_admin INTEGER NOT NULL DEFAULT 0,
        auto_renew INTEGER NOT NULL DEFAULT 0)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS images(
        id INTEGER PRIMARY KEY, label TEXT NOT NULL, ref TEXT UNIQUE NOT NULL)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS plans(
        id INTEGER PRIMARY KEY, name TEXT NOT NULL, price REAL NOT NULL DEFAULT 0,
        cpu REAL NOT NULL, ram_mb INTEGER NOT NULL, disk_mb INTEGER NOT NULL DEFAULT 0,
        image_id INTEGER NOT NULL REFERENCES images(id))");
    $pdo->exec("CREATE TABLE IF NOT EXISTS services(
        id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
        plan_id INTEGER NOT NULL REFERENCES plans(id), name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'active', expires_at INTEGER NOT NULL,
        suspended_at INTEGER, created_at INTEGER NOT NULL)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS log(
        id INTEGER PRIMARY KEY, service_id INTEGER, msg TEXT, at INTEGER)");

    if (!$pdo->query("SELECT COUNT(*) c FROM images")->fetch()['c']) {
        $ins = $pdo->prepare("INSERT INTO images(label,ref) VALUES(?,?)");
        $ins->execute(['Debian 12', 'debian:bookworm-slim']);
        $ins->execute(['Ubuntu 24.04', 'ubuntu:24.04']);
        $ins->execute(['Node.js 22', 'node:22-bookworm-slim']);
        $ins->execute(['Python 3.12', 'python:3.12-slim']);
    }
    if (!$pdo->query("SELECT COUNT(*) c FROM plans")->fetch()['c']) {
        $ins = $pdo->prepare("INSERT INTO plans(name,price,cpu,ram_mb,disk_mb,image_id) VALUES(?,?,?,?,?,?)");
        $ins->execute(['Lemon Mini', 0,  0.5, 512,  2048,  1]);
        $ins->execute(['Lemon Pro',  10, 1,   2048, 10240, 1]);
        $ins->execute(['Lemon Max',  25, 2,   4096, 25600, 1]);
    }
    return $pdo;
}

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf(): string { $_SESSION['csrf'] ??= bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function csrf_ok(): bool { return hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? ''); }
function go(string $u) { header("Location: $u"); exit; }
function flash(?string $m = null): string {
    if ($m !== null) { $_SESSION['flash'] = $m; return ''; }
    $f = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']); return $f;
}
function me(): ?array {
    if (empty($_SESSION['uid'])) return null;
    $s = db()->prepare("SELECT * FROM users WHERE id=?");
    $s->execute([$_SESSION['uid']]);
    return $s->fetch() ?: null;
}
const SVC_SQL = "SELECT s.*, p.name plan, p.price, p.cpu, p.ram_mb, p.disk_mb, i.ref image
    FROM services s JOIN plans p ON p.id=s.plan_id JOIN images i ON i.id=p.image_id";
function svc_owned(int $id, int $uid): ?array {
    $s = db()->prepare(SVC_SQL . " WHERE s.id=? AND s.user_id=? AND s.status!='deleted'");
    $s->execute([$id, $uid]);
    return $s->fetch() ?: null;
}
function logmsg(int $sid, string $msg): void {
    db()->prepare("INSERT INTO log(service_id,msg,at) VALUES(?,?,?)")->execute([$sid, $msg, time()]);
}

/** Yenileme. Fiyat 0 olsa bile yenileme gerekir; yenilenmezse süre dolunca askıya alınır. */
function renew_service(int $sid, bool $auto = false): bool {
    $pdo = db();
    $pdo->beginTransaction();
    $s = $pdo->prepare("SELECT s.*, p.price, u.credits FROM services s
        JOIN plans p ON p.id=s.plan_id JOIN users u ON u.id=s.user_id WHERE s.id=?");
    $s->execute([$sid]);
    $r = $s->fetch();
    if (!$r || $r['status'] === 'deleted' || $r['credits'] < $r['price']) {
        $pdo->rollBack();
        return false;
    }
    $pdo->prepare("UPDATE users SET credits=credits-? WHERE id=?")->execute([$r['price'], $r['user_id']]);
    $exp = max(time(), (int)$r['expires_at']) + cfg('period_days') * 86400;
    $pdo->prepare("UPDATE services SET expires_at=?, status='active', suspended_at=NULL WHERE id=?")
        ->execute([$exp, $sid]);
    $pdo->commit();
    if ($r['status'] === 'suspended') docker_start(svc_container($sid));
    logmsg($sid, ($auto ? 'Oto yenileme' : 'Yenileme') . " ({$r['price']} kredi)");
    return true;
}

require_once __DIR__ . '/docker.php';
